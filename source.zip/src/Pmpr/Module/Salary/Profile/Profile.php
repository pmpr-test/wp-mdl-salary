<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8a01dc2a8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Container; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Container { public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->caokeucsksukesyo()->cqusmgskowmesgcg()->iqqgmieeqemiowuk("\160\141\x6e\x65\x6c")) { Panel::symcgieuakksimmu(); } } }
