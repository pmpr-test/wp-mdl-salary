<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0aecf0a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Container; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Container { public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->caokeucsksukesyo()->cqusmgskowmesgcg()->iqqgmieeqemiowuk("\160\x61\x6e\x65\x6c")) { Panel::symcgieuakksimmu(); } } }
