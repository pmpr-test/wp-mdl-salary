<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da352a37c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Container; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Container { public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->caokeucsksukesyo()->cqusmgskowmesgcg()->iqqgmieeqemiowuk("\x70\x61\x6e\145\x6c")) { Panel::symcgieuakksimmu(); } } }
