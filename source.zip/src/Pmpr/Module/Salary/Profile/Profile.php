<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce971af77             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Container; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Container { public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->caokeucsksukesyo()->cqusmgskowmesgcg()->iqqgmieeqemiowuk("\x70\141\156\x65\154")) { Panel::symcgieuakksimmu(); } } }
