<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92eacf41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile; use Pmpr\Module\Salary\Profile\Panel\Panel; class Profile extends Common { public function mameiwsayuyquoeq() { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $this->omseesogaocascyo("\160\x61\156\145\154"))) { goto yoqakewookqoqacm; } Panel::symcgieuakksimmu(); yoqakewookqoqacm: } }
