<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678aa10caa194             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\Tab; use Pmpr\Module\Salary\Profile\Admin\ListTable\ProductListTable; class Product extends Tab { public function __construct() { $this->id = "\x70\162\157\144\x75\143\x74\x73"; $this->title = __("\120\x72\x6f\x64\165\143\164\163", PR__MDL__SALARY); $this->priority = 50; parent::__construct(); } public function gayqqwwuycceosii() : array { $qsyooiqcmkcieyuk = new ProductListTable(); return ["\154\x69\163\x74\x5f\x74\141\142\x6c\145" => $qsyooiqcmkcieyuk]; } }
