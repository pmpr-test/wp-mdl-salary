<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7bd939ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\Tab; use Pmpr\Module\Salary\Profile\Admin\ListTable\ProductListTable; class Product extends Tab { public function __construct() { $this->id = "\160\x72\157\144\165\143\x74\163"; $this->title = __("\x50\162\x6f\x64\165\143\x74\x73", PR__MDL__SALARY); $this->priority = 50; parent::__construct(); } public function gayqqwwuycceosii() : array { $qsyooiqcmkcieyuk = new ProductListTable(); return ["\x6c\x69\163\164\137\x74\141\x62\154\x65" => $qsyooiqcmkcieyuk]; } }
