<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f9939cde6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\Tab; use Pmpr\Module\Salary\Profile\Admin\ListTable\ProductListTable; class Product extends Tab { public function __construct() { $this->id = "\160\x72\x6f\x64\165\x63\164\x73"; $this->title = __("\x50\x72\157\x64\x75\x63\164\163", PR__MDL__SALARY); $this->priority = 50; parent::__construct(); } public function gayqqwwuycceosii() : array { $qsyooiqcmkcieyuk = new ProductListTable(); return ["\154\x69\x73\164\x5f\164\141\x62\x6c\x65" => $qsyooiqcmkcieyuk]; } }
