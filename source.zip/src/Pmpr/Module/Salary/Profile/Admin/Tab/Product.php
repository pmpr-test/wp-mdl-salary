<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d981593db9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\Tab; use Pmpr\Module\Salary\Profile\Admin\ListTable\ProductListTable; class Product extends Tab { public function __construct() { $this->id = "\x70\x72\x6f\x64\x75\143\x74\x73"; $this->title = __("\120\x72\157\144\165\143\x74\163", PR__MDL__SALARY); $this->priority = 50; parent::__construct(); } public function gayqqwwuycceosii() : array { $qsyooiqcmkcieyuk = new ProductListTable(); return ["\x6c\x69\x73\164\137\164\141\142\154\x65" => $qsyooiqcmkcieyuk]; } }
