<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b7508a143             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\Tab; use Pmpr\Module\Salary\Profile\Admin\ListTable\ProductListTable; class Product extends Tab { public function __construct() { $this->id = "\160\162\x6f\144\165\x63\x74\x73"; $this->title = __("\x50\162\x6f\144\165\143\x74\x73", PR__MDL__SALARY); $this->priority = 50; parent::__construct(); } public function gayqqwwuycceosii() : array { $qsyooiqcmkcieyuk = new ProductListTable(); return ["\154\151\163\x74\137\164\141\x62\x6c\x65" => $qsyooiqcmkcieyuk]; } }
