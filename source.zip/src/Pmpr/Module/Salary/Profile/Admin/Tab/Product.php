<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6775ab16ac1ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\Tab; use Pmpr\Module\Salary\Profile\Admin\ListTable\ProductListTable; class Product extends Tab { public function __construct() { $this->id = "\x70\x72\x6f\144\x75\143\x74\163"; $this->title = __("\x50\162\x6f\x64\x75\x63\164\x73", PR__MDL__SALARY); $this->priority = 50; parent::__construct(); } public function gayqqwwuycceosii() : array { $qsyooiqcmkcieyuk = new ProductListTable(); return ["\x6c\x69\163\164\x5f\164\141\142\154\x65" => $qsyooiqcmkcieyuk]; } }
