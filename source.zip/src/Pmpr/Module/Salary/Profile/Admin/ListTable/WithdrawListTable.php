<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92eacf41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Profile\Admin\ListTable; use Pmpr\Module\Salary\Model\Withdraw; class WithdrawListTable extends ORMListTable { public function get_columns() : array { $wkkweuacukumqmya = []; $meywaqqsugaoeyys = $this->mgogaykgkoogasim(); if (!$meywaqqsugaoeyys instanceof Withdraw) { goto yuimwyoywaiiqacs; } $oammesyieqmwuwyi = [$meywaqqsugaoeyys::owmueawayysqcsqo, $meywaqqsugaoeyys::aioqyewkwawaqgqe => __("\101\155\x6f\165\156\x74", PR__MDL__SALARY), $meywaqqsugaoeyys::ciywsqoeiymemsys]; $wkkweuacukumqmya = $this->ewgmueueeycoikso($oammesyieqmwuwyi); yuimwyoywaiiqacs: return $wkkweuacukumqmya; } }
