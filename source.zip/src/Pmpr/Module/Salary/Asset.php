<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec9a0855e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\x66\157\x72\x65\137\x65\156\161\x75\x65\165\x65\137\x62\x61\143\153\145\x6e\x64\x5f\141\163\163\x65\164\163", [$this, "\x65\156\161\165\x65\165\x65"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto sciwggaeogcoesiu; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\x64\155\151\x6e", $eygsasmqycagyayw->get("\141\x64\x6d\151\156\56\152\163"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\141\x6a\141\170", Ajax::myikkigscysoykgy); sciwggaeogcoesiu: } }
