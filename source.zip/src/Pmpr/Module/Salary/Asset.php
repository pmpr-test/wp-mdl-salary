<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae92eacf41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary; class Asset extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\146\157\162\145\137\145\156\161\165\145\x75\x65\x5f\142\141\x63\x6b\x65\156\144\137\141\x73\x73\145\x74\163", [$this, "\145\x6e\x71\x75\x65\165\145"]); } public function enqueue() { if (!($eygsasmqycagyayw = $this->miocmcoykayoyyau())) { goto mugqyyeayeyggqqk; } $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\144\155\x69\156", $eygsasmqycagyayw->get("\x61\144\155\151\x6e\56\152\163"))->simswskycwagoeqy())->ikqyiskqaaymscgw("\x61\x6a\x61\170", Ajax::myikkigscysoykgy); mugqyyeayeyggqqk: } }
