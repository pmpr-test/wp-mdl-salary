<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169d9311d4d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Salary\Reseller; use Pmpr\Module\Salary\Container; class Reseller extends Container { }
