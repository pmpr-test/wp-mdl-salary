<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da352a37c             |
    |_______________________________________|
*/
 use Pmpr\Module\Salary\Salary; Salary::symcgieuakksimmu();
