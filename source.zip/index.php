<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0aecf0a9             |
    |_______________________________________|
*/
 use Pmpr\Module\Salary\Salary; Salary::symcgieuakksimmu();
