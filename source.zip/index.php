<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb317f48c             |
    |_______________________________________|
*/
 use Pmpr\Module\Salary\Salary; Salary::symcgieuakksimmu();
