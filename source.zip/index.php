<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d4c22efb8             |
    |_______________________________________|
*/
 use Pmpr\Module\Salary\Salary; Salary::symcgieuakksimmu();
